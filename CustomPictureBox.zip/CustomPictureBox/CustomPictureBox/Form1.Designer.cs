﻿namespace CustomPictureBox
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.customPictureBox2 = new CustomePictureBox.CustomPictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.customPictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // customPictureBox2
            // 
            this.customPictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("customPictureBox2.BackgroundImage")));
            this.customPictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.customPictureBox2.Location = new System.Drawing.Point(1, 1);
            this.customPictureBox2.Name = "customPictureBox2";
            this.customPictureBox2.Size = new System.Drawing.Size(241, 229);
            this.customPictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.customPictureBox2.TabIndex = 0;
            this.customPictureBox2.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(247, 231);
            this.Controls.Add(this.customPictureBox2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CustomPictureBox";
            ((System.ComponentModel.ISupportInitialize)(this.customPictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private CustomePictureBox.CustomPictureBox customPictureBox1;
        private CustomePictureBox.CustomPictureBox customPictureBox2;
    }
}